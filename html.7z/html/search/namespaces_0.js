var searchData=
[
  ['interface_5fv1',['Interface_v1',['../namespace_interface__v1.html',1,'']]],
  ['properties',['Properties',['../namespace_interface__v1_1_1_properties.html',1,'Interface_v1']]]
];
