var searchData=
[
  ['onfigurepress',['OnFigurePress',['../class_interface__v1_1_1_two___players.html#a4bd67da9ea6cb7923f9a9279b350f7f5',1,'Interface_v1::Two_Players']]]
];
