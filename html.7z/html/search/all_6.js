var searchData=
[
  ['init',['Init',['../class_interface__v1_1_1_two___players.html#a307bfef08d4fb6851e6949ac786f03f3',1,'Interface_v1::Two_Players']]],
  ['interface',['Interface',['../class_interface__v1_1_1_interface.html',1,'Interface_v1']]],
  ['interface',['Interface',['../class_interface__v1_1_1_interface.html#ab315d7ca71a9323ae919faaba8bc37ae',1,'Interface_v1::Interface']]],
  ['interface_2ecs',['Interface.cs',['../_interface_8cs.html',1,'']]],
  ['interface_5fv1',['Interface_v1',['../namespace_interface__v1.html',1,'']]],
  ['isbuttonhaseatstep',['IsButtonHasEatStep',['../class_interface__v1_1_1_two___players.html#a9e96af689d4076b3398a28f43b8aad8c',1,'Interface_v1::Two_Players']]],
  ['isinsideborders',['IsInsideBorders',['../class_interface__v1_1_1_two___players.html#a5c21236c17506fa11c2ffbb528f902ab',1,'Interface_v1::Two_Players']]],
  ['properties',['Properties',['../namespace_interface__v1_1_1_properties.html',1,'Interface_v1']]]
];
