var searchData=
[
  ['resetgame',['ResetGame',['../class_interface__v1_1_1_two___players.html#a82d7c5087f7e02a48d78e687e5b4c1cd',1,'Interface_v1::Two_Players']]]
];
