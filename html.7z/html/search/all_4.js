var searchData=
[
  ['getfigureimage',['GetFigureImage',['../class_interface__v1_1_1_two___players.html#a2cebcb3fdbf0852df2bc9025a50b5ef6',1,'Interface_v1::Two_Players']]],
  ['getprevbuttoncolor',['GetPrevButtonColor',['../class_interface__v1_1_1_two___players.html#afa54c1bfec457e5a857373dc0dc54d22',1,'Interface_v1::Two_Players']]]
];
