var searchData=
[
  ['whitescoreimage',['WhiteScoreImage',['../class_interface__v1_1_1_two___players.html#adfe2300e3b07ba868bbaa17ef15d7ce2',1,'Interface_v1::Two_Players']]]
];
