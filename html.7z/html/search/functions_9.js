var searchData=
[
  ['showdiagonal',['ShowDiagonal',['../class_interface__v1_1_1_two___players.html#af31a39c6d19f931a7cf62ee852ff4ea2',1,'Interface_v1::Two_Players']]],
  ['showpossiblesteps',['ShowPossibleSteps',['../class_interface__v1_1_1_two___players.html#a371aec2f4bc1c58bf5430d376a5a8911',1,'Interface_v1::Two_Players']]],
  ['showproceduraleat',['ShowProceduralEat',['../class_interface__v1_1_1_two___players.html#a7af384ef246009d88db4c74d7d454738',1,'Interface_v1::Two_Players']]],
  ['showsteps',['ShowSteps',['../class_interface__v1_1_1_two___players.html#a454db1b0bfb22b2312602dbf33228cc3',1,'Interface_v1::Two_Players']]],
  ['switchbuttontocheat',['SwitchButtonToCheat',['../class_interface__v1_1_1_two___players.html#a5f38de119cdebce8b0a08a543d57eea6',1,'Interface_v1::Two_Players']]],
  ['switchplayer',['SwitchPlayer',['../class_interface__v1_1_1_two___players.html#aead82230948723465d3a4340a9525eea',1,'Interface_v1::Two_Players']]]
];
