var searchData=
[
  ['undo',['Undo',['../class_interface__v1_1_1_two___players.html#a322f71c010b6bb8908afc0f984e9bed7',1,'Interface_v1::Two_Players']]]
];
